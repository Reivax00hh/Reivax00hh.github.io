# Kingdom Hearts II GOA Randomizer Map Tracker
This pack is designed for the [Garden of Assemblage Randomizer](https://docs.google.com/document/d/1GYjEnrM_TIk7qyO75clPLYD-_nP5wTR7K6SE-Wn-QCg/edit#)

## Variants
This pack has only 2 variants:

1. Map Tracker
2. Items Only

##Settings
There are 4 settings that add checks, these are -

- ![Absent Silhouettes](images/absent.png "Absent Silhouettes") This adds where the Absent Silhouette fights are on the maps.
- ![Data Org](images/non-existentproof.png "Data Org") This adds the Data Org checks to the Cavern of Remembrance.
- ![Lingering Will](images/lingering.png "Lingering Will") This adds the Lingering Will check to Disney Castle.
- ![Sephirothl](images/sephiroth.png "Sephiroth") This adds the Sephiroth check to Hollow Bastion.